package main

import (
	"archive/tar"
	"archive/zip"
	"bytes"
	"encoding/binary"
	"errors"
	"image"
	"image/jpeg"
	_ "image/gif"
	_ "image/png"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"strings"
)

const coverReadLimit = 24 << 20
const audioCoverChunk = 4 << 20

// DecodeConfig reads image dimensions without allocating the raster. Enforce
// a decoded-pixel budget before allowing JPEG/PNG processing on small hosts.
const maxCoverDimension = 8192
const maxCoverDecodedPixels int64 = 12000000

func safeCoverDimensions(width, height int) bool {
	return width > 0 && height > 0 &&
		width <= maxCoverDimension && height <= maxCoverDimension &&
		int64(width)*int64(height) <= maxCoverDecodedPixels
}

func safeImageData(data []byte) ([]byte, string, error) {
	if len(data) == 0 || len(data) > coverReadLimit {
		return nil, "", errors.New("cover unavailable")
	}
	mime := http.DetectContentType(data)
	// Do not allow a tiny compressed JPEG, PNG or GIF with an enormous declared
	// raster to exhaust a Raspberry Pi or NAS before thumbnail generation.
	switch mime {
	case "image/jpeg", "image/png", "image/gif":
		config, _, err := image.DecodeConfig(bytes.NewReader(data))
		if err != nil || !safeCoverDimensions(config.Width, config.Height) {
			return nil, "", errors.New("cover dimensions exceed safe memory limits or image is invalid")
		}
	case "image/webp":
		if _, _, err := webpCanvasDimensions(data); err != nil {
			return nil, "", err
		}
	}
	switch mime {
	case "image/jpeg", "image/png":
		src, _, err := image.Decode(bytes.NewReader(data))
		if err != nil { return nil, "", err }
		b := src.Bounds()
		w, h := b.Dx(), b.Dy()
		if w <= 420 && h <= 640 {
			return data, mime, nil
		}
		scale := 1.0
		if w > 420 { scale = 420.0 / float64(w) }
		if float64(h)*scale > 640 { scale = 640.0 / float64(h) }
		nw, nh := int(float64(w)*scale), int(float64(h)*scale)
		if nw < 1 { nw = 1 }; if nh < 1 { nh = 1 }
		dst := image.NewRGBA(image.Rect(0,0,nw,nh))
		for y:=0; y<nh; y++ {
			sy := b.Min.Y + y*h/nh
			for x:=0; x<nw; x++ {
				sx := b.Min.X + x*w/nw
				dst.Set(x,y,src.At(sx,sy))
			}
		}
		var out bytes.Buffer
		if err = jpeg.Encode(&out,dst,&jpeg.Options{Quality:82}); err != nil { return nil, "", err }
		return out.Bytes(), "image/jpeg", nil
	case "image/webp", "image/gif":
		return data, mime, nil
	default:
		return nil, "", errors.New("unsupported cover image")
	}
}

func readLimited(f *os.File) ([]byte,error) {
	info, err := f.Stat()
	if err != nil || !info.Mode().IsRegular() || info.Size() <= 0 || info.Size() > coverReadLimit {
		return nil, errors.New("cover unavailable")
	}
	return io.ReadAll(io.LimitReader(f,coverReadLimit+1))
}

func externalCover(root, rel string) ([]byte,string,error) {
	dirRel := filepath.Dir(rel)
	base := strings.TrimSuffix(filepath.Base(rel),filepath.Ext(rel))
	r, err := os.OpenRoot(root)
	if err != nil { return nil,"",err }
	defer r.Close()

	names := []string{base+".jpg",base+".jpeg",base+".png",base+".webp"}
	if genericFolderArtworkAllowed(r,dirRel) {
		names=append(names,
			"cover.jpg","cover.jpeg","cover.png","cover.webp",
			"front.jpg","front.jpeg","front.png","front.webp",
			"front-cover.jpg","front-cover.jpeg","front-cover.png","front-cover.webp",
			"book-cover.jpg","book-cover.jpeg","book-cover.png","book-cover.webp",
			"folder.jpg","folder.jpeg","folder.png","folder.webp",
			"coverart.jpg","coverart.jpeg","coverart.png","coverart.webp",
			"artwork.jpg","artwork.jpeg","artwork.png","artwork.webp",
		)
	}
	for _, name := range names {
		candidate := filepath.Join(dirRel,name)
		f, openErr := r.Open(candidate)
		if openErr != nil { continue }
		data, readErr := readLimited(f); f.Close()
		if readErr != nil { continue }
		if thumb,mime,thumbErr:=safeImageData(data);thumbErr==nil{return thumb,mime,nil}
	}
	return nil,"",errors.New("cover not found")
}

func genericFolderArtworkAllowed(root *os.Root, dirRel string) bool {
	dir,err:=root.Open(dirRel)
	if err!=nil{return false}
	defer dir.Close()
	entries,err:=dir.ReadDir(-1)
	if err!=nil{return false}
	mediaCount:=0
	allAudio:=true
	audioTrackLike:=true
	for _,entry:=range entries{
		if entry.IsDir(){continue}
		ext:=strings.ToLower(filepath.Ext(entry.Name()))
		if !coverMediaExtension(ext){continue}
		mediaCount++
		if !coverAudioExtension(ext){
			allAudio=false
			continue
		}
		stem:=strings.TrimSuffix(entry.Name(),filepath.Ext(entry.Name()))
		if !genericAudioTrackLabel(stem)&&!leadingNumberedAudioTrack(stem){audioTrackLike=false}
	}
	return mediaCount==1 || (mediaCount>1&&allAudio&&audioTrackLike)
}

func coverMediaExtension(ext string) bool {
	switch ext {
	case ".epub",".pdf",".cbz",".cbr",".cbt",".zip",".mp3",".m4a",".m4b",".aac",".ogg",".opus",".flac":
		return true
	default:
		return false
	}
}

func coverAudioExtension(ext string) bool {
	switch ext {
	case ".mp3",".m4a",".m4b",".aac",".ogg",".opus",".flac":
		return true
	default:
		return false
	}
}

// Restrict expensive candidate decoding, including corrupt/archive-bomb
// covers, while permitting a damaged first image to fall back to real artwork.
const maxCoverCandidateAttempts = 64

func archiveCover(root, rel, format string) ([]byte,string,error) {
    r, err := os.OpenRoot(root)
    if err != nil { return nil,"",err }
    defer r.Close()
    f, err := r.Open(rel)
    if err != nil { return nil,"",err }
    defer f.Close()
    info, err := f.Stat()
    if err != nil { return nil,"",err }
    ext := strings.ToLower(filepath.Ext(rel))
    if format=="Comic" && ext==".cbr" {
        parts, e := rarComicParts(f)
        if e!=nil{return nil,"",e}
        for i,name:=range parts {
            if i>=maxCoverCandidateAttempts {break}
            data,e:=rarComicEntry(f,name,coverReadLimit)
            if e!=nil{continue}
            if safe,mime,e:=safeImageData(data);e==nil{return safe,mime,nil}
        }
        return nil,"",errors.New("cover not found")
    }
    if format=="Comic" && ext==".cbt" {
        tr:=tar.NewReader(f)
        attempts:=0
        entries:=0
        for {
            h,e:=tr.Next()
            if e==io.EOF{break}
            if e!=nil{return nil,"",e}
            entries++
            if entries>maxTarComicEntries{return nil,"",errors.New("comic contains too many entries")}
            if h.Typeflag!=tar.TypeReg && h.Typeflag!=tar.TypeRegA{continue}
            switch strings.ToLower(path.Ext(h.Name)){case ".jpg",".jpeg",".png",".webp":
                if h.Size<=0 || h.Size>coverReadLimit{continue}
                if attempts>=maxCoverCandidateAttempts{return nil,"",errors.New("cover not found")}
                attempts++
                data,e:=io.ReadAll(io.LimitReader(tr,coverReadLimit+1))
                if e!=nil{continue}
                if safe,mime,e:=safeImageData(data);e==nil{return safe,mime,nil}
            }
        }
        return nil,"",errors.New("cover not found")
    }
    z,err:=zip.NewReader(f,info.Size())
    if err!=nil{return nil,"",err}
    if len(z.File)>maxTarComicEntries{return nil,"",errors.New("archive contains too many entries")}
    var fallbackData []byte
    var fallbackMIME string
    attempts:=0
    for _,zf:=range z.File {
        if zf.FileInfo().IsDir()||zf.UncompressedSize64>coverReadLimit{continue}
        suffix:=strings.ToLower(path.Ext(zf.Name))
        if suffix!=".jpg" && suffix!=".jpeg" && suffix!=".png" && suffix!=".webp" && suffix!=".gif"{continue}
        isEbookCover:=format!="Ebook"||strings.Contains(strings.ToLower(zf.Name),"cover")
        if !isEbookCover&&fallbackData!=nil{continue}
        if attempts>=maxCoverCandidateAttempts{break}
        attempts++
        rc,e:=zf.Open()
        if e!=nil{continue}
        data,e:=io.ReadAll(io.LimitReader(rc,coverReadLimit+1))
        if closeErr:=rc.Close();e==nil{e=closeErr}
        if e!=nil || len(data)>coverReadLimit{continue}
        safe,mime,e:=safeImageData(data)
        if e!=nil{continue}
        if isEbookCover{return safe,mime,nil}
        // EPUB fallback may be a useful illustration, but a valid dedicated
        // cover later in the archive always takes priority over it.
        if fallbackData==nil {fallbackData=safe;fallbackMIME=mime}
    }
    if fallbackData!=nil{return fallbackData,fallbackMIME,nil}
    return nil,"",errors.New("cover not found")
}

func audioEmbeddedCover(root, rel string) ([]byte,string,error) {
	r,err:=os.OpenRoot(root)
	if err!=nil{return nil,"",err}
	defer r.Close()
	f,err:=r.Open(rel)
	if err!=nil{return nil,"",err}
	defer f.Close()
	info,err:=f.Stat()
	if err!=nil||!info.Mode().IsRegular(){return nil,"",errors.New("cover unavailable")}
	ext:=strings.ToLower(filepath.Ext(rel))
	read:=func(offset,length int64)[]byte{
		if length<=0{return nil}
		if _,e:=f.Seek(offset,io.SeekStart);e!=nil{return nil}
		buf:=make([]byte,length);n,_:=io.ReadFull(f,buf);return buf[:n]
	}
	length:=int64(audioCoverChunk)
	if info.Size()<length{length=info.Size()}
	head:=read(0,length)
	var imageData []byte
	switch ext {
	case ".mp3":
		imageData=id3EmbeddedPicture(head)
	case ".m4a",".m4b":
		imageData=mp4Data(head,[]byte{'c','o','v','r'})
		if len(imageData)==0&&info.Size()>length{
			tailLength:=int64(audioCoverChunk);if info.Size()<tailLength{tailLength=info.Size()}
			imageData=mp4Data(read(info.Size()-tailLength,tailLength),[]byte{'c','o','v','r'})
		}
	default:
		return nil,"",errors.New("cover unavailable")
	}
	if len(imageData)==0{return nil,"",errors.New("cover unavailable")}
	return safeImageData(imageData)
}

func id3EmbeddedPicture(data []byte) []byte {
	if len(data)<10||string(data[:3])!="ID3"||(data[3]!=3&&data[3]!=4){return nil}
	version:=data[3]
	end:=10+synchsafeID3(data[6:10]);if end>len(data){end=len(data)}
	var fallback []byte
	for offset:=10;offset+10<=end;{
		id:=string(data[offset:offset+4])
		if strings.Trim(id,"\x00 ")==""{break}
		frameSize:=0
		if version==4{frameSize=synchsafeID3(data[offset+4:offset+8])}else{frameSize=int(binary.BigEndian.Uint32(data[offset+4:offset+8]))}
		if frameSize<=0||offset+10+frameSize>end{break}
		if id=="APIC"{
			frame:=data[offset+10:offset+10+frameSize]
			if image,pictureType:=parseAPICPicture(frame);len(image)>0{
				if pictureType==3{return image}
				if fallback==nil{fallback=image}
			}
		}
		offset+=10+frameSize
	}
	return fallback
}

func parseAPICPicture(frame []byte)([]byte,byte){
	if len(frame)<6{return nil,0}
	encoding:=frame[0]
	cursor:=1
	mimeEnd:=bytes.IndexByte(frame[cursor:],0);if mimeEnd<0{return nil,0};cursor+=mimeEnd+1
	if cursor>=len(frame){return nil,0}
	pictureType:=frame[cursor];cursor++
	if encoding==1||encoding==2{
		found:=-1
		for i:=cursor;i+1<len(frame);i+=2{if frame[i]==0&&frame[i+1]==0{found=i;break}}
		if found<0{return nil,0};cursor=found+2
	}else{
		descriptionEnd:=bytes.IndexByte(frame[cursor:],0);if descriptionEnd<0{return nil,0};cursor+=descriptionEnd+1
	}
	if cursor>=len(frame)||len(frame)-cursor>coverReadLimit{return nil,0}
	return frame[cursor:],pictureType
}

func (a *app) assetCover(id string) ([]byte,string,error) {
	var root, rel, format string
	err:=a.db.QueryRow(`SELECT s.path,a.relative_path,a.format
		FROM assets a JOIN sources s ON s.id=a.source_id
		WHERE a.id=? AND a.available=1`,id).Scan(&root,&rel,&format)
	if err!=nil{return nil,"",err}
	if data,mime,e:=externalCover(root,rel);e==nil{return data,mime,nil}
	if format=="Audio" { if data,mime,e:=audioEmbeddedCover(root,rel);e==nil{return data,mime,nil} }
	if format=="Comic" || format=="Ebook" {
		if data,mime,e:=archiveCover(root,rel,format);e==nil{return data,mime,nil}
	}
	return nil,"",errors.New("cover unavailable")
}

func (a *app) workCover(id string) ([]byte,string,error) {
	var root, rel, format string
	err:=a.db.QueryRow(`SELECT s.path,a.relative_path,a.format FROM works w
		JOIN editions e ON e.work_id=w.id JOIN edition_assets ea ON ea.edition_id=e.id
		JOIN assets a ON a.id=ea.asset_id JOIN sources s ON s.id=a.source_id
		WHERE w.id=? AND a.available=1 ORDER BY e.id,ea.position LIMIT 1`,id).Scan(&root,&rel,&format)
	if err!=nil{return nil,"",err}
	if data,mime,e:=externalCover(root,rel);e==nil{return data,mime,nil}
	if format=="Audio" { if data,mime,e:=audioEmbeddedCover(root,rel);e==nil{return data,mime,nil} }
	if format=="Comic" || format=="Ebook" {
		if data,mime,e:=archiveCover(root,rel,format);e==nil{return data,mime,nil}
	}
	return nil,"",errors.New("cover unavailable")
}

func writeCoverResponse(w http.ResponseWriter,data []byte,mime string) {
	w.Header().Set("Content-Type",mime)
	w.Header().Set("Cache-Control","private, max-age=86400")
	w.Header().Set("X-Content-Type-Options","nosniff")
	w.Write(data)
}

func (a *app) coverRoutes(mux *http.ServeMux) {
	mux.HandleFunc("GET /api/assets/{id}/cover",func(w http.ResponseWriter,r *http.Request){
		data,mime,err:=a.assetCover(r.PathValue("id"))
		if err!=nil { http.NotFound(w,r); return }
		writeCoverResponse(w,data,mime)
	})
	mux.HandleFunc("GET /api/works/{id}/cover",func(w http.ResponseWriter,r *http.Request){
		data,mime,err:=a.workCover(r.PathValue("id"))
		if err!=nil { http.NotFound(w,r); return }
		writeCoverResponse(w,data,mime)
	})
}
